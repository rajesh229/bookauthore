function saveAuthore(){

    const xhr=new XMLHttpRequest()
    xhr.open('POST', '/uploadimg', true);
   var authorname=$("#exampleInputName").val();
   var name=$("#exampleInputbookName").val()

   var file=$("#image").get(0).files
  var  formData = new FormData();
  formData.append("authorename",authorname)
  formData.append("bookname",name)
  formData.append("image",file)
alert("hi")
$.ajax({
    url:"http://localhost:3000/uploadimg",
    data:formData,
    dataType:"JSON",
    type:"POST",
    enctype="multipart/form-data",
    processData : false,
   //cache : false,
    success:function(responce){
        console.log(responce)
        
    }
})

// xhr.onreadystatechange=function(){

//     if(xhr.status == 200){
//        // document.querySelector('#addBookModal').innerHTML = errorMessage;
//        // return;
//        console.log("hiihiii")
//       }
//       if(xhr.status == 400) {
//         if(xhr.responseText.includes('Error')){
//             console.log(xhr.responseText);
        
//         }
//         console.log(JSON.parse(xhr.responseText));
//        // document.querySelector('#addBookModal').innerHTML = success;
//       }
// }
// xhr.send(formData);
// //document.querySelector('#addBookModal').innerHTML = progress;
}